#!/bin/sh

wget -X html -nH -r http://lirc.org
